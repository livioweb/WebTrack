<?php
class Foo
{
    public function bar()
    {
        return Foo::CLASS;
    }
}

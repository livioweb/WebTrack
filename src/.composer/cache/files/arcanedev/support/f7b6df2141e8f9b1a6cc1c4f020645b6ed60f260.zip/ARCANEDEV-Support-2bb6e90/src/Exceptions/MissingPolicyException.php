<?php namespace Arcanedev\Support\Exceptions;

/**
 * Class     MissingPolicyException
 *
 * @package  Arcanedev\Support\Exceptions
 * @author   ARCANEDEV <arcanedev.maroc@gmail.com>
 */
class MissingPolicyException extends \Exception {}

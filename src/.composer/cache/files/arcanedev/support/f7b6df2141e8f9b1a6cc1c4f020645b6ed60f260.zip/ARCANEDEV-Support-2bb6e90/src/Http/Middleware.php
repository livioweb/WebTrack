<?php namespace Arcanedev\Support\Http;

/**
 * Class     Middleware
 *
 * @package  Arcanedev\Support\Laravel
 * @author   ARCANEDEV <arcanedev.maroc@gmail.com>
 */
abstract class Middleware
{
    //
}

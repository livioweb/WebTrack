<?php

return [
    'all'       => 'Tous',
    'emergency' => 'Urgence',
    'alert'     => 'Alerte',
    'critical'  => 'Critique',
    'error'     => 'Erreur',
    'warning'   => 'Avertissement',
    'notice'    => 'Notice',
    'info'      => 'Info',
    'debug'     => 'Debug',
];

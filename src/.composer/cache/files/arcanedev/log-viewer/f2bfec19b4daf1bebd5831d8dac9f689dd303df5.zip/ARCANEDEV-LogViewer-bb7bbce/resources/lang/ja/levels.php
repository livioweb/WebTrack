<?php

return [
    'all'       => 'すべて',
    'emergency' => '緊急',
    'alert'     => '警戒',
    'critical'  => '致命的',
    'error'     => 'エラー',
    'warning'   => '警告',
    'notice'    => '通知',
    'info'      => '情報',
    'debug'     => 'デバッグ',
];

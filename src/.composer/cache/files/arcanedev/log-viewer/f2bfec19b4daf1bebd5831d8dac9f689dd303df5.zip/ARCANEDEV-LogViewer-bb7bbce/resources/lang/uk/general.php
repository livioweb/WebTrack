<?php
 
return [
    'all'        => 'Всі',
    'date'       => 'Дата',
    'empty-logs' => 'Список журналів порожній!',
];

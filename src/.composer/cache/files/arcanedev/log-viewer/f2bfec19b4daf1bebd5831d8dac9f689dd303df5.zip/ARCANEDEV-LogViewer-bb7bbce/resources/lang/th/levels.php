<?php

return [
    'all'       => 'ทั้งหมด',
    'emergency' => 'ฉุกเฉิน',
    'alert'     => 'วิกฤติ',
    'critical'  => 'ร้ายแรง',
    'error'     => 'ข้อผิดพลาด',
    'warning'   => 'คำเตือน',
    'notice'    => 'ประกาศ',
    'info'      => 'ข้อมูล',
    'debug'     => 'ดีบัก',
];

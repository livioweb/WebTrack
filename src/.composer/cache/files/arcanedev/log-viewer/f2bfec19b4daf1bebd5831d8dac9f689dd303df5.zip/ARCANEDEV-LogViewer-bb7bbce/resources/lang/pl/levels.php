<?php

return [
    'all'       => 'Wszystkie',
    'emergency' => 'Awaryjne',
    'alert'     => 'Alerty',
    'critical'  => 'Krytyczne',
    'error'     => 'Błędy',
    'warning'   => 'Ostrzeżenia',
    'notice'    => 'Warte uwagi',
    'info'      => 'Informacje',
    'debug'     => 'Debug',
];

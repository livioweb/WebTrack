<?php

return [
    'all'        => 'Tous',
    'date'       => 'Date',
    'empty-logs' => 'La liste des logs est vide!',
];

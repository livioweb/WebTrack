<?php

return [
    'all'        => 'Todos',
    'date'       => 'Fecha',
    'empty-logs' => 'La lista del log está vacía!',
];

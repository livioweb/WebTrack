<?php

return [
    'all'       => 'Toate',
    'emergency' => 'Urgență',
    'alert'     => 'Alertă',
    'critical'  => 'Critic',
    'error'     => 'Eroare',
    'warning'   => 'Pericol',
    'notice'    => 'Avertisment',
    'info'      => 'Informare',
    'debug'     => 'Depanare',
];

<?php

return [
    'all'       => 'Összes',
    'emergency' => 'Vészhelyzet',
    'alert'     => 'Riasztás',
    'critical'  => 'Kritikus',
    'error'     => 'Hiba',
    'warning'   => 'Figyelmeztetés',
    'notice'    => 'Értesítés',
    'info'      => 'Információ',
    'debug'     => 'Hibakeresés',
];

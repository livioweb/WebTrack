<?php

return [
    'all'       => '전체',
    'emergency' => '긴급',
    'alert'     => '경고',
    'critical'  => '심각',
    'error'     => '오류',
    'warning'   => '주의',
    'notice'    => '알림',
    'info'      => '정보',
    'debug'     => '디버그',
];

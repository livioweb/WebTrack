<?php

return [
    'all'       => 'Alle',
    'emergency' => 'Notfall',
    'alert'     => 'Alarm',
    'critical'  => 'Kritisch',
    'error'     => 'Fehler',
    'warning'   => 'Warnung',
    'notice'    => 'Hinweis',
    'info'      => 'Info',
    'debug'     => 'Debug',
];

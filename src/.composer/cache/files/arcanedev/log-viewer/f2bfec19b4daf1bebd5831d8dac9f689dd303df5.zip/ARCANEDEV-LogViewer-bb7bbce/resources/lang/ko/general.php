<?php

return [
    'all'        => '전체',
    'date'       => '날짜',
    'empty-logs' => '로그가 없습니다.',
];
